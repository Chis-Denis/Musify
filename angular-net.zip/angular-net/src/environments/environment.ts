export const environment = {
  production: false,
  apiUrl: 'https://localhost:44383/api'
}; 