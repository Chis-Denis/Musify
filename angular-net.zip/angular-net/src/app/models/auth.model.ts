export class UserLogin {
  email!: string;
  password!: string;
  constructor(value?: Partial<UserLogin>) {
    if (value) Object.assign(this, value);
  }
}

export class UserRegister {
  firstName!: string;
  lastName!: string;
  email!: string;
  password!: string;
  country!: string;
  constructor(value?: Partial<UserRegister>) {
    if (value) Object.assign(this, value);
  }
}

export class AuthResponse {
  token!: string;
  constructor(value?: Partial<AuthResponse>) {
    if (value) Object.assign(this, value);
  }
} 