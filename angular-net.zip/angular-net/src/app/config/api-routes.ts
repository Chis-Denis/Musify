// API endpoints
export const ApiRoutes = {
  auth: '/auth',
  login: '/login',
};

// Angular navigation paths
export const RoutePaths = {
  home: 'home',
  login: 'login',
};

// Angular Router config
import { Routes } from '@angular/router';
import { LoginComponent } from '../components/auth/login/login.component';
import { HomeComponent } from '../components/home/home.component';

export const routes: Routes = [
  { path: RoutePaths.login, component: LoginComponent },
  { path: RoutePaths.home, component: HomeComponent },
  { path: '', redirectTo: `/${RoutePaths.login}`, pathMatch: 'full' }
]; 