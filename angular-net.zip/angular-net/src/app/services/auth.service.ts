import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserLogin, UserRegister, AuthResponse } from '../models/auth.model';
import { environment } from '../../environments/environment';
import { ApiRoutes } from '../config/api-routes';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  login(credentials: UserLogin): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(
      `${this.apiUrl}${ApiRoutes.auth}${ApiRoutes.login}`,
      credentials
    );
  }
}